from importlib.resources import Resource
from utils import *
import csv, datetime, itertools, collections


@app.route('/ping', methods=["POST"])
def ping():
    print("Pong~")
    return Response("200")


@app.route('/', methods=["POST"])
def hello_world():
    raw = request.data.decode("utf-8")
    """ Log 작성 """
    # with open('./http_test.txt', 'a') as fd:
    #     fd.write(str(raw) + "\n")
    """ Key Value Mapping """
    dic = json.loads(raw)
    msg = dic['message']
    res = dict(item.split("=") for item in msg.split("|"))
    # print(res)
    # print(dic.keys(), type(dic), len(dic), "\n", res.keys(), type(res), len(res))
    del dic["message"]
    """ message key value와 전체 key value 통합 """
    r = dict(res, **dic)
    """ Last Report Timestamp 저장 Device ID : { ts, rssi } """
    # print(r)
    if "DEVICE_ID" in r:
        cache.hmset(r["DEVICE_ID"], {'ts': str(datetime.datetime.now().timestamp()), 'rssi': r['AP_RSSI']})
    elif "deviceId" in r:
        cache.hmset(r["deviceId"], {'ts': str(datetime.datetime.now().timestamp()), 'rssi': r['rssi']})

    """ DB에서 Context Awareness Table 가져와서 감지 """
    if cache.exists(r["MODEL_NAME"]):
        cal_args = cache.hmget(r["MODEL_NAME"], "param", "operator", "threshold")
        params, comparison_operator, threshold = list(map(lambda x: x.decode(), cal_args))
        res = Operator.calculate(comparison_operator, r[params], threshold)
        print("> ", datetime.datetime.now(), "Calculation [", r["DEVICE_ID"], params, "]: ", r[params], comparison_operator, threshold, " is ", res)
        """ Alert Post 전송 """
        if res is True:
            Alerts.post(r["MODEL_NAME"], r["DEVICE_ID"])
            pass
    else:
        # todo : 지금 들어온 Raw 데이터에 해당하는 상황인지 설정 값이 없음. 설정 값을 추가 해야함.
        pass

    if cache.exists(r["modelName"]):
        # todo : 현대렌탈케어, 에브리봇 필드 명
        print("존재함")

    return Response("200")


# Test Route
@alerts.route("/")
class Alerts(Resource):
    @staticmethod
    def get():
        """ Redis 확인용 """
        print("[GET] Redis Keys")
        print(cache.exists("model_list"), cache.smembers("model_list"))
        keys = cache.keys()
        # print(keys)
        for key in keys:
            args = list(cache.hgetall(key))
            # print(args, type(args))
            for arg in args:
                print(">>", key.decode(), "|", arg.decode(), ":", cache.hmget(key, arg.decode())[0].decode())

        return str(keys)

    @staticmethod
    def post(model, device):
        """ API G/W로 POST 전달. """
        """ Redis 저장된 설정 정보 읽음."""
        hash_args = cache.hmget(model, "keyword",
                               "title",
                               "description",
                               "report_interval",
                               "pdf_id",
                               "page_num")

        key, title, des, interval, pdf, page = list(map(lambda x: x.decode(), hash_args))
        post_data = {
            "siteProductSeq": device,
            "keyword": title,
            "detailMassge": des,
            "urlPath": "http://218.55.23.208:5000/pdfjs?page=" + page
            # "urlPath": API_GW_URL_PATH + pdf + "?page=" + page_num
        }
        # DB 테이블 손수 넣어야됨.
        """ POST API G/W로 전송"""
        # res = sent_api_gw(test_data)
        # print(res)
        print(">>", post_data)
        return Response("200")


def sent_api_gw(_dict):
    log(1, "Log Test")
    print("[POST] Sent Dict Test: ", _dict, type(_dict))
    response = requests.post(API_GATEWAY_URL, json=_dict)
    return response


@app.route("/pdfjs")  # todo : /pdfjs -> /<file_name>?page=6 명명 변경   아래꺼 완성 전까지 냅두기
def get():
    page_num = request.args.get('page')
    if page_num is None:
        page_num = 1
    return render_template("index.html",
                           file="http://218.55.23.208:5000/static/pdf_manual_01.pdf",
                           page_num=page_num)


# @app.route("/<filename>")   # todo :  API
# def get2(filename):
#     filename = filename
#     print("Test >>> ", filename)
#     page_num = request.args.get('page')
#     if page_num is None:
#         page_num = 1
#     return render_template("index.html",
#                            file="http://218.55.23.208:5000/static/" + filename,
#                            page_num=page_num)
