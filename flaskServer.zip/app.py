from utils import *
from apis import *
from batch import *


if __name__ == '__main__':
    app.run(threaded=True, host="218.55.23.208", port=5000, debug=False)

